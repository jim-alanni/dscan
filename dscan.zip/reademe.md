dscan

```python
dscan 基于python开发的多线程目录扫描工具
使用简单:
	python dscan.py <url>
```

